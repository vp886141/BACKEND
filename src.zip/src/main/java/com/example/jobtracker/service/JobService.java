package com.example.jobtracker.service;

import com.example.jobtracker.model.Job;
import com.example.jobtracker.repository.JobRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class JobService {

    private final JobRepository jobRepository;

    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    // ADD JOB
    public Job addJob(Job job) {
        return jobRepository.save(job);
    }

    // GET ALL JOBS (by user)
    public List<Job> getJobsByUser(String email) {
        return jobRepository.findByUserEmail(email);
    }

    // DELETE
    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    // UPDATE JOB
    public Job updateJob(Long id, Job updatedJob) {
        Job job = jobRepository.findById(id).orElseThrow();

        job.setCompany(updatedJob.getCompany());
        job.setRole(updatedJob.getRole());
        job.setStatus(updatedJob.getStatus());
        job.setFollowUpDate(updatedJob.getFollowUpDate());
        job.setTag(updatedJob.getTag());

        return jobRepository.save(job);
    }

    // SEARCH
    public List<Job> searchJobs(String company) {
        return jobRepository.findByCompanyContainingIgnoreCase(company);
    }

    // FILTER
    public List<Job> filterJobs(String status) {
        return jobRepository.findByStatus(status);
    }

    // DASHBOARD STATS
    public Map<String, Long> getStats() {
        Map<String, Long> stats = new HashMap<>();

        stats.put("Applied", jobRepository.countByStatus("APPLIED"));
        stats.put("Interview", jobRepository.countByStatus("INTERVIEW"));
        stats.put("Offer", jobRepository.countByStatus("OFFER"));
        stats.put("Rejected", jobRepository.countByStatus("REJECTED"));

        return stats;
    }
}