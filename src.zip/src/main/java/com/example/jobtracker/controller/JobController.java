package com.example.jobtracker.controller;

import com.example.jobtracker.model.Job;
import com.example.jobtracker.service.JobService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/jobs")
@CrossOrigin
public class JobController {

    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    // ADD JOB
    @PostMapping("/add")
    public Job addJob(@RequestBody Job job) {
        return jobService.addJob(job);
    }

    // GET JOBS
    @GetMapping("/{email}")
    public List<Job> getJobs(@PathVariable String email) {
        return jobService.getJobsByUser(email);
    }

    // DELETE JOB
    @DeleteMapping("/delete/{id}")
    public void deleteJob(@PathVariable Long id) {
        jobService.deleteJob(id);
    }

    // UPDATE JOB
    @PutMapping("/update/{id}")
    public Job updateJob(@PathVariable Long id, @RequestBody Job job) {
        return jobService.updateJob(id, job);
    }

    // SEARCH
    @GetMapping("/search")
    public List<Job> searchJobs(@RequestParam String company) {
        return jobService.searchJobs(company);
    }

    // FILTER
    @GetMapping("/filter")
    public List<Job> filterJobs(@RequestParam String status) {
        return jobService.filterJobs(status);
    }

    // STATS
    @GetMapping("/stats")
    public Map<String, Long> getStats() {
        return jobService.getStats();
    }
}