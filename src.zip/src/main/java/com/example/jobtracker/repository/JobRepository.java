package com.example.jobtracker.repository;

import com.example.jobtracker.model.Job;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {

    List<Job> findByUserEmail(String userEmail);

    List<Job> findByCompanyContainingIgnoreCase(String company);

    List<Job> findByStatus(String status);

    long countByStatus(String status);
}